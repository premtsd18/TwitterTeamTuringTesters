package com.premtsd.twitter.teamturingtesters.dto;

import lombok.Data;

@Data
public class ConnectionRequestDto {
    private long userId1;
    private long userId2;
}
