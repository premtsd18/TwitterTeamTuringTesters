package com.premtsd.twitter.teamturingtesters.dto;

import lombok.Data;

@Data
public class ConnectionFollowerRequestDto {
    private long userId;
}
